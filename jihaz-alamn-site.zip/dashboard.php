<?php
// بوابة تحويل بحسب الرتبة
session_start();
$rank = $_POST['rank'] ?? '';
switch ($rank) {
    case 'studies': header('Location: ranks/studies.php'); break;
    case 'reviewer': header('Location: ranks/reviewer.php'); break;
    case 'archive': header('Location: ranks/archive.php'); break;
    case 'general': header('Location: ranks/general.php'); break;
    default: echo 'رتبة غير صحيحة';
}
?>